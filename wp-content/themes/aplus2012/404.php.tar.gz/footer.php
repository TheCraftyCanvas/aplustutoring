<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 */
?>

	</div><!-- #main -->
	</div><!--/#content-wrapper-->
</div><!--/#wrapper-->

<footer id="colophon" role="contentinfo">
  <div id="footer-content-bg">
    <div id="footer-content-bgtop">
      <div id="footer-content">
        <?php /* A sidebar in the footer? Yep. You can can customize your footer with three columns of widgets */
          if ( ! is_404() )
            get_sidebar( 'footer' );
        ?>
      </div><!--/#footer-content-->
    </div><!--/#footer-content-bgtop-->
  </div><!--/#footer-content-bg-->
  <div id="footer">
    <p style="font-size:11px;font-style:italic;padding-bottom:2px;">The "<span style="font-weight:bold;color:#cb0000;font-size:14px;">+</span>" in A+ is the personalized and customized attention given to each student.</p>
    <p style="font-size:9px;padding-top:2px;">&copy;2012, A+ Test Prep &amp; Tutoring, Inc.</p>
  </div><!--/#footer-->
</footer><!-- #colophon -->


<?php wp_footer(); ?>

</body>
</html>