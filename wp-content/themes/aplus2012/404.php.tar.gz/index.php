<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 */

get_header(); ?>

<?php if ( is_home() || is_front_page() ) : ?>
		<div id="banner">
			<ul>

        <?php
          $post_limit = -1; // set to -1 to show all
          $args = array(
            'post_type' => 'featured-services',
            'posts_per_page' => $post_limit,
            'orderby' => 'menu_order',
            'order' => 'asc'
            );

          $loop = new WP_Query( $args );
          $firstFlag = 0;
          if ( $loop->have_posts() ) : while ( $loop->have_posts() ) : $loop->the_post();
        ?>

				<li <?php if($firstFlag==0) { echo 'class="first"'; } $firstFlag++; ?> >
					<div id="<?php echo 'cbox' . $firstFlag; ?>" class="box">
						<div class="rctl"></div><div class="rctr"></div><div class="rcbl"></div><div class="rcbr"></div>
						<div class="box-overlay">
							<div class="heading"><?php the_title(); ?></div>
							<div class="content">
								<p><?php echo (types_render_field("callout-content", array('output' => 'html' ) ) );?></p>
								<p><?php echo (types_render_field("callout-link", array('output' => 'raw', 'class' => 'link-style2', 'title' => 'Learn More' ) ) );?></p>
							</div>
						</div>
						<div class="image-style5 image-style5a"><a href="#"><?php echo (types_render_field("callout-image", array("alt"=>get_the_title(),
      "width"=>"240","proportional"=>"true") ) ); ?><!--<img src="<?php bloginfo('template_directory'); ?>/images/pics01.jpg" style="width:240px;height:323px;" alt="" />--><span></span></a></div>
					</div>
				</li>

        <?php
          endwhile;
          endif;
        ?>
			</ul>
		</div><!--/#banner-->



		<div id="page">
			<div id="three-columns">
				<div id="column1">
					<h2 class="title">Lorem Ipsum Dolor</h2>
					<div class="image-style3 image-style3a"><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/pics05.jpg" width="300" height="108" alt="" /><span></span></a></div>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras varius lorem et lectus consequat elementum. Nullam varius quam semper urna accumsan id rhoncus ante tincidunt nullam varius quam semper urna accumsan consequat.</p>
					<p><a href="#" class="link-style1">Learn More</a></p>
				</div>
				<div id="column2">
					<h2 class="title">Lorem Ipsum Dolor</h2>
					<div class="image-style3 image-style3a"><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/pics06.jpg" width="300" height="108" alt="" /><span></span></a></div>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras varius lorem et lectus consequat elementum. Nullam varius quam semper urna accumsan id rhoncus ante tincidunt nullam varius quam semper urna accumsan consequat.</p>
					<p><a href="#" class="link-style1">Learn More</a></p>
				</div>
				<div id="column3">
					<h2 class="title">Recent News</h2>
					<ul class="style3">
						<li class="first"><span><a href="#">May 1</a></span><a href="#">Lorem ipsum dolor sit amet lorem sed amet tempus et lectus consequat.</a></li>
						<li><span><a href="#">Apr 30</a></span><a href="#">Lorem ipsum dolor sit amet lorem sed amet tempus et lectus consequat.</a></li>
						<li><span><a href="#">Apr 24</a></span><a href="#">Lorem ipsum dolor sit amet lorem sed amet tempus et lectus consequat.</a></li>
					</ul>
					<p><a href="#" class="link-style1">Learn More</a></p>
				</div>
			</div>
		</div><!--/#page-->

<?php else: ?>

		<div id="page">
		<div id="primary">
			<div id="content" role="main">

			<?php if ( have_posts() ) : ?>

				<?php twentyeleven_content_nav( 'nav-above' ); ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'content', get_post_format() ); ?>

				<?php endwhile; ?>

				<?php twentyeleven_content_nav( 'nav-below' ); ?>

			<?php else : ?>

				<article id="post-0" class="post no-results not-found">
					<header class="entry-header">
						<h1 class="entry-title"><?php _e( 'Nothing Found', 'twentyeleven' ); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyeleven' ); ?></p>
						<?php get_search_form(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-0 -->

			<?php endif; ?>

			</div><!-- #content -->
		</div><!-- #primary -->

  <?php get_sidebar(); ?>
  </div><!--/#page-->

<?php endif; ?>

<?php get_footer(); ?>